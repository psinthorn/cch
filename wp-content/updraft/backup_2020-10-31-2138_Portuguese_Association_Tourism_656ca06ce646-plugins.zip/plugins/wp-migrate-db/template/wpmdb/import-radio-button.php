<li class="import-list">
	<label for="import" class="disabled upgrade-pro">
		<input id="import" type="radio" value="import" name="action" disabled="disabled" />
		<span class="upgrade-pro"><?php _ex( 'Import', 'Import data from a SQL file', 'wp-migrate-db' ); ?></span><span class="option-description"><a href="https://deliciousbrains.com/wp-migrate-db-pro/upgrade/?utm_campaign=WP%2BMigrate%2BDB%2BPro%2BUpgrade&utm_source=MDB%2BFree&utm_medium=insideplugin&utm_content=upgrade-import" target="_blank"><?php _e( 'Upgrade to Pro', 'wp-migrate-db' ); ?></a> <?php _e( 'to import SQL files', 'wp-migrate-db' ); ?></span>
	</label>
	<ul>
		<li>
		</li>
	</ul>
</li>
