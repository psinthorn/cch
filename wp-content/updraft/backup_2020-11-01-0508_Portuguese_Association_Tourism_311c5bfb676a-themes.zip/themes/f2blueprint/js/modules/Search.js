class Search {
    constructor() {
        // alert("Hello Live Seach");
    }
}

export default Search;